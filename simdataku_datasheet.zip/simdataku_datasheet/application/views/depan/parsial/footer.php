<style>
  .float{
	position:fixed;
	width:60px;
	height:60px;
	bottom:40px;
	left:40px;
	background-color:#25d366;
	color:#FFF;
	border-radius:50px;
	text-align:center;
  font-size:30px;
	box-shadow: 2px 2px 3px #999;
  z-index:100;
}

.my-float{
	margin-top:16px;
}
</style>
<!-- ======= Footer ======= -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
<a href="https://api.whatsapp.com/send?phone=+62370631722&text=Halo." class="float" target="_blank">
<i class="fa fa-whatsapp my-float"></i>
</a>

<footer id="footer">

<div class="footer-top">
  <div class="container">
    <div class="row">

      <div class="col-lg-3 col-md-4 col-sm-3 col-6 footer-contact">
        <h3>SIMDATAKU</h3>
        <p>
         

        JL. Airlangga, No. 36,<br> 
        Mataram, NTB, 83126, <br>
         <br>
        Mataram City, West Nusa Tenggara,Indonesia 
        <br><br>
          <strong>Telpn:</strong> 0812-3782-130<br>
          <strong>Email:</strong> support@simdataku.com<br>
        </p>
      </div>

      <div class="col-lg-3 col-md-6 col-sm-3 col-6 footer-links">
        <h4>Navigasi</h4>
        <ul>
          <li><i class="bx bx-chevron-right"></i> <a href="<?php echo site_url(''); ?>">Beranda</a></li>
          <li><i class="bx bx-chevron-right"></i> <a href="<?php echo site_url('umkm'); ?>">UMKM</a></li>
          <!--  -->
        </ul>
      </div>

      

      <div class="col-lg-3 col-md-6 col-sm-3 col-6 footer-links">
        <h4>Sosial media kami</h4>
        <p>Sosial media resmi Dinas Koperasi Provinsi NTB</p>
        <div class="social-links mt-3">
          <a href="#" class="twitter"><i class="bx bxl-twitter"></i></a>
          <a href="#" class="facebook"><i class="bx bxl-facebook"></i></a>
          <a href="#" class="instagram"><i class="bx bxl-instagram"></i></a>
          <a href="#" class="youtube"><i class="bx bxl-youtube"></i></a>
          <a href="#" class="soundcloud"><i class="bx bxl-soundcloud"></i></a>
        </div>
      </div>

    </div>
  </div>
</div>

<div class="container footer-bottom clearfix">
  <div class="copyright">
    &copy;Copyright 2021<strong><span><a href="https://diskop.ntbprov.go.id/">Dinas Koperasi Provinsi Nusa Tenggara Barat</a></span></strong>. All Rights Reserved
  </div>
  
</div>
</footer><!-- End Footer -->

<a href="#" class="back-to-top"><i class="ri-arrow-up-line"></i></a>
<div id="preloader"></div>

  <script src="<?= base_url('assets/js/jquery.dataTables.min.js'); ?>"></script>
  <script src="<?= base_url('assets/vendor/waypoints/jquery.waypoints.min.js'); ?>"></script>